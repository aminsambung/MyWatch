package com.mywatch.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF061426)
private val Card = Color(0xFF102744)
private val Blue = Color(0xFF168BFF)
private val Muted = Color(0xFF9CB3CC)
private val White = Color(0xFFF4F8FF)

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var stepSensor: Sensor? = null
    private var baseline = -1f
    private var steps by mutableIntStateOf(0)
    private var sensorAvailable by mutableStateOf(false)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startStepSensor()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        sensorAvailable = stepSensor != null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION)
        } else {
            startStepSensor()
        }
        setContent {
            MyWatchPhoneApp(
                steps = steps,
                sensorAvailable = sensorAvailable,
                onRequestPermission = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                        permissionLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION)
                }
            )
        }
    }

    private fun startStepSensor() {
        stepSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_STEP_COUNTER) {
            val totalSinceBoot = event.values[0]
            if (baseline < 0f) {
                baseline = getPreferences(Context.MODE_PRIVATE).getFloat("step_baseline", -1f)
                if (baseline < 0f || totalSinceBoot < baseline) {
                    baseline = totalSinceBoot
                    getPreferences(Context.MODE_PRIVATE).edit().putFloat("step_baseline", baseline).apply()
                }
            }
            steps = (totalSinceBoot - baseline).toInt().coerceAtLeast(0)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    override fun onPause() { super.onPause(); sensorManager.unregisterListener(this) }
    override fun onResume() {
        super.onResume()
        if (::sensorManager.isInitialized && (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED)) {
            startStepSensor()
        }
    }
}

data class Metric(val title: String, val value: String, val unit: String, val icon: ImageVector, val tint: Color, val note: String)

@Composable
fun MyWatchPhoneApp(steps: Int, sensorAvailable: Boolean, onRequestPermission: () -> Unit) {
    var selected by remember { mutableIntStateOf(0) }
    val calories = (steps * 0.04).toInt()
    val km = String.format("%.2f", steps * 0.0007).replace('.', ',')
    val metrics = listOf(
        Metric("Detak jantung", "—", "", Icons.Default.Favorite, Color(0xFFFF5577), "Perlu sensor khusus"),
        Metric("Langkah hari ini", "%,d".format(steps), "langkah", Icons.Default.DirectionsWalk, Color(0xFF20C8F5), if (sensorAvailable) "Dari sensor HP" else "Sensor langkah tidak tersedia"),
        Metric("Kalori", "$calories", "kkal", Icons.Default.LocalFireDepartment, Color(0xFFFFA52E), "Perkiraan dari langkah"),
        Metric("Tidur", "—", "", Icons.Default.Bedtime, Color(0xFFAA78FF), "Catat manual"),
        Metric("Jarak", km, "km", Icons.Default.LocationOn, Color(0xFF20C8F5), "Perkiraan dari langkah"),
        Metric("Baterai HP", "—", "", Icons.Default.BatteryFull, Color(0xFF31D59A), "Bisa ditambahkan")
    )
    MaterialTheme(colorScheme = darkColorScheme(background = Navy, surface = Card, primary = Blue, onBackground = White, onSurface = White)) {
        Scaffold(containerColor = Navy, bottomBar = {
            NavigationBar(containerColor = Color(0xFF091B31), contentColor = Muted) {
                listOf("Beranda", "Kesehatan", "Aktivitas", "Profil").forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = selected == i, onClick = { selected = i },
                        icon = { Icon(when (i) { 0 -> Icons.Default.Home; 1 -> Icons.Default.Favorite; 2 -> Icons.Default.DirectionsWalk; else -> Icons.Default.Person }, contentDescription = label) },
                        label = { Text(label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Blue, selectedTextColor = Blue, indicatorColor = Color(0xFF173A61), unselectedIconColor = Muted, unselectedTextColor = Muted)
                    )
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text("My Watch", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(5.dp))
                        Text("Mode HP · tanpa smartwatch", color = Muted, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.PhoneAndroid, contentDescription = "HP", tint = Blue, modifier = Modifier.size(28.dp))
                }
                Spacer(Modifier.height(18.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Langkah terdeteksi dari HP", color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(5.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text("%,d".format(steps), color = White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(6.dp)); Text("/ 10.000 langkah", color = Muted, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(progress = { (steps / 10000f).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(7.dp), color = Blue, trackColor = Color(0xFF203B5A))
                        if (!sensorAvailable) {
                            Spacer(Modifier.height(8.dp))
                            Text("HP ini tidak melaporkan sensor penghitung langkah.", color = Color(0xFFFFC36A), fontSize = 11.sp)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(listOf("Ringkasan", "Kesehatan", "Aktivitas", "Profil")[selected], color = White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 14.dp)) {
                    items(metrics) { metric ->
                        Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp), modifier = Modifier.height(132.dp)) {
                            Column(Modifier.padding(14.dp).fillMaxSize()) {
                                Icon(metric.icon, contentDescription = null, tint = metric.tint, modifier = Modifier.size(23.dp))
                                Spacer(Modifier.height(9.dp))
                                Text(metric.title, color = Muted, fontSize = 12.sp)
                                Spacer(Modifier.height(3.dp))
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(metric.value, color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                                    if (metric.unit.isNotEmpty()) { Spacer(Modifier.width(4.dp)); Text(metric.unit, color = Muted, fontSize = 10.sp) }
                                }
                                Spacer(Modifier.height(3.dp))
                                Text(metric.note, color = Muted, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
