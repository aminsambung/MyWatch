MY WATCH — MODE HP SAJA

Versi ini dirancang untuk dipakai langsung di HP Android/Vivo, tanpa menghubungkan smartwatch.
Yang aktif: penghitung langkah memakai sensor langkah bawaan HP jika tersedia. Kalori dan jarak
ditampilkan sebagai perkiraan dari langkah, bukan pengukuran GPS.

Detak jantung tidak dapat diukur oleh kebanyakan HP Vivo karena membutuhkan sensor khusus.
Pemantauan tidur pada versi ini belum otomatis.

Membuat APK:
1. Ekstrak ZIP ini di komputer.
2. Buka folder melalui Android Studio.
3. Tunggu Gradle Sync dan pastikan Android SDK 35 terpasang.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. File debug biasanya ada di app/build/outputs/apk/debug/app-debug.apk.

Catatan: Ini proyek sumber, bukan file APK siap instal. Perlu Android Studio untuk membangun APK.
